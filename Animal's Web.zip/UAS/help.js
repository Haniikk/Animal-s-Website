//Validtion Code For Inputs

function popap() {
    var email = document.getElementById("email").value;
    var alamat = document.getElementById("alamat").value;
    if (email != "" && alamat != "") {
        alert('Pesan berhasil');
        document.getElementById("pesan").reset();
    } else {
        alert('Isi semua data terlebih dahulu');
    }
}

// Declare all variables
var i,
    articleContent = document.querySelectorAll(".article-content"),
    articleLinks = document.querySelectorAll(".article-list"),
    articleContentItem = document.querySelectorAll(".article-content-info"),
    acc = document.querySelectorAll(".article-content-header");

// Get the first element with a class of "article-list-item-anchor" and click on it
for (i = 0; i < articleLinks.length; i++) {
    articleLinks[0].click();
}

// tabs function
function showContent(evt, trigName) {
    // Get all elements with class="tabcontent" and hide them
    for (i = 0; i < articleContent.length; i++) {
        articleContent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    for (i = 0; i < articleLinks.length; i++) {
        articleLinks[i].className = articleLinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(trigName).style.display = "block";
    evt.currentTarget.className += " active";
}

// accordions function
for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function() {
        /* Toggle between adding and removing the "active" class,
             to highlight the button that controls the panel */
        this.classList.toggle("active");
        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.height) {
            panel.style.height = null;
            panel.style.padding = null;
            panel.style.transform = "scale(0.9875)";
        } else {
            panel.style.height = panel.scrollHeight + 70 + "px";
            panel.style.padding = "25px";
            panel.style.transform = "scale(1)";
        }
    };
}